import React from 'react'

export default function Explore() {
  return (
    <div>Explore</div>
  )
}
